package com.AMRCapstone.amrserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmrserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmrserverApplication.class, args);
	}

}
