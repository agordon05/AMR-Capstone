package com.AMRCapstone.amrserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmrserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
